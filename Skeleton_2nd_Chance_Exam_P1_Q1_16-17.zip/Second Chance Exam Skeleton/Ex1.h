/* ----------------------------------------------------------------------- */
/*                         INSERT YOUR NAME HERE                           */
/* ----------------------------------------------------------------------- */

#ifndef EX1_H
#define EX1_H

// TO DO: Define the types byte and ushort here

int isContained(byte b, ushort u)
{
	

	// TO DO: Insert the code of the function here


}


#endif