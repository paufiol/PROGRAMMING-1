/* ----------------------------------------------------------------------- */
/*                         INSERT YOUR NAME HERE                           */
/* ----------------------------------------------------------------------- */

#ifndef EX2_H
#define EX2_H



// TO DO: Declare the data type Weapon here



int rowMaxAvgDamage(struct Weapon armoryCloset[4][3])
{


	// TO DO: Insert the code of the function here


}

int colMinAvgAmmo(struct Weapon armoryCloset[4][3])
{


	// TO DO: Insert the code of the function here


}

#endif