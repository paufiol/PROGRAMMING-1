/* ----------------------------------------------------------------------- */
/*                         INSERT YOUR NAME HERE                           */
/* ----------------------------------------------------------------------- */

#ifndef EX3_H
#define EX3_H

#include <stdio.h>

int countCharInFile(char* filename, char c)
{


	// TO DO: Insert the code of the function here


}

#endif