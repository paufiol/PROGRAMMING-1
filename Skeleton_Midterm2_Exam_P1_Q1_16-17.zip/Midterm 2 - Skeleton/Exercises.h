/* ----------------------------------------------------------------------- */
/*                          INSERT YOUR NAME HERE                          */
/* ----------------------------------------------------------------------- */

#ifndef EXERCISES_H
#define EXERCISES_H

#include <stdio.h>
#include <string.h>

typedef unsigned char byte;


// -- EXERCISE 1 --
int minPlusMax(int* vec, unsigned int sizeVec)
{
	// TO DO: Insert your code here
}



// -- EXERCISE 2 --

// TO DO: Declare the new data type pixel here

int compareTiles(struct pixel tile1[8][8], struct pixel tile2[8][8])
{
	// TO DO: Insert your code here
}



// -- EXERCISE 3 --
int countWordInFile(char* filename, char* word)
{
	// TO DO: Insert your code here	
}


#endif